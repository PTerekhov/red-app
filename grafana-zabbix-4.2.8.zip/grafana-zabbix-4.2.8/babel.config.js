module.exports = {
  "presets": [
    [ "@babel/preset-env", { "targets": { "node": "current" } } ],
    "@babel/react"
  ],
  "retainLines": true
};
