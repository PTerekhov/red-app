/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
define(["@grafana/data","@grafana/runtime","react","@grafana/ui"], (__WEBPACK_EXTERNAL_MODULE__grafana_data__, __WEBPACK_EXTERNAL_MODULE__grafana_runtime__, __WEBPACK_EXTERNAL_MODULE_react__, __WEBPACK_EXTERNAL_MODULE__grafana_ui__) => { return /******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./components/ConfigEditor.tsx":
/*!*************************************!*\
  !*** ./components/ConfigEditor.tsx ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   ConfigEditor: () => (/* binding */ ConfigEditor)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _grafana_ui__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @grafana/ui */ \"@grafana/ui\");\n/* harmony import */ var _grafana_ui__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_grafana_ui__WEBPACK_IMPORTED_MODULE_1__);\nfunction _define_property(obj, key, value) {\n    if (key in obj) {\n        Object.defineProperty(obj, key, {\n            value: value,\n            enumerable: true,\n            configurable: true,\n            writable: true\n        });\n    } else {\n        obj[key] = value;\n    }\n    return obj;\n}\nfunction _object_spread(target) {\n    for(var i = 1; i < arguments.length; i++){\n        var source = arguments[i] != null ? arguments[i] : {};\n        var ownKeys = Object.keys(source);\n        if (typeof Object.getOwnPropertySymbols === \"function\") {\n            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {\n                return Object.getOwnPropertyDescriptor(source, sym).enumerable;\n            }));\n        }\n        ownKeys.forEach(function(key) {\n            _define_property(target, key, source[key]);\n        });\n    }\n    return target;\n}\nfunction ownKeys(object, enumerableOnly) {\n    var keys = Object.keys(object);\n    if (Object.getOwnPropertySymbols) {\n        var symbols = Object.getOwnPropertySymbols(object);\n        if (enumerableOnly) {\n            symbols = symbols.filter(function(sym) {\n                return Object.getOwnPropertyDescriptor(object, sym).enumerable;\n            });\n        }\n        keys.push.apply(keys, symbols);\n    }\n    return keys;\n}\nfunction _object_spread_props(target, source) {\n    source = source != null ? source : {};\n    if (Object.getOwnPropertyDescriptors) {\n        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));\n    } else {\n        ownKeys(Object(source)).forEach(function(key) {\n            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));\n        });\n    }\n    return target;\n}\n\n\nfunction ConfigEditor(props) {\n    const { onOptionsChange, options } = props;\n    const onTnsChange = (event)=>{\n        const jsonData = _object_spread_props(_object_spread({}, options.jsonData), {\n            tns: event.target.value\n        });\n        onOptionsChange(_object_spread_props(_object_spread({}, options), {\n            jsonData\n        }));\n    };\n    const onUserChange = (event)=>{\n        const jsonData = _object_spread_props(_object_spread({}, options.jsonData), {\n            user: event.target.value\n        });\n        onOptionsChange(_object_spread_props(_object_spread({}, options), {\n            jsonData\n        }));\n    };\n    // Secure field (only sent to the backend)\n    const onPasswordChange = (event)=>{\n        onOptionsChange(_object_spread_props(_object_spread({}, options), {\n            secureJsonData: {\n                password: event.target.value\n            }\n        }));\n    };\n    const onResetPassword = ()=>{\n        onOptionsChange(_object_spread_props(_object_spread({}, options), {\n            secureJsonFields: _object_spread_props(_object_spread({}, options.secureJsonFields), {\n                password: false\n            }),\n            secureJsonData: _object_spread_props(_object_spread({}, options.secureJsonData), {\n                password: ''\n            })\n        }));\n    };\n    const { jsonData, secureJsonFields } = options;\n    const secureJsonData = options.secureJsonData || {};\n    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(\"div\", {\n        className: \"gf-form-group\"\n    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_1__.InlineField, {\n        label: \"TNS\",\n        labelWidth: 6\n    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_1__.Input, {\n        onChange: onTnsChange,\n        value: jsonData.tns || '',\n        placeholder: \"string TNS\",\n        width: 120\n    })), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_1__.InlineField, {\n        label: \"User\",\n        labelWidth: 12\n    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_1__.Input, {\n        onChange: onUserChange,\n        value: jsonData.user || '',\n        placeholder: \"username\",\n        width: 40\n    })), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_1__.InlineField, {\n        label: \"Password\",\n        labelWidth: 12\n    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_1__.SecretInput, {\n        isConfigured: secureJsonFields && secureJsonFields.password,\n        value: secureJsonData.password || '',\n        placeholder: \"secure json field (backend only)\",\n        width: 40,\n        onReset: onResetPassword,\n        onChange: onPasswordChange\n    })));\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL0NvbmZpZ0VkaXRvci50c3giLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQTJDO0FBQ21CO0FBTXZELFNBQVNJLGFBQWFDLEtBQVk7SUFDdkMsTUFBTSxFQUFFQyxlQUFlLEVBQUVDLE9BQU8sRUFBRSxHQUFHRjtJQUVyQyxNQUFNRyxjQUFjLENBQUNDO1FBQ25CLE1BQU1DLFdBQVcsd0NBQ1pILFFBQVFHLFFBQVE7WUFDbkJDLEtBQUtGLE1BQU1HLE1BQU0sQ0FBQ0MsS0FBSzs7UUFFekJQLGdCQUFnQix3Q0FBS0M7WUFBU0c7O0lBQ2hDO0lBRUEsTUFBTUksZUFBZSxDQUFDTDtRQUNwQixNQUFNQyxXQUFXLHdDQUNaSCxRQUFRRyxRQUFRO1lBQ25CSyxNQUFNTixNQUFNRyxNQUFNLENBQUNDLEtBQUs7O1FBRTFCUCxnQkFBZ0Isd0NBQUtDO1lBQVNHOztJQUNoQztJQUVBLDBDQUEwQztJQUMxQyxNQUFNTSxtQkFBbUIsQ0FBQ1A7UUFDeEJILGdCQUFnQix3Q0FDWEM7WUFDSFUsZ0JBQWdCO2dCQUNkQyxVQUFVVCxNQUFNRyxNQUFNLENBQUNDLEtBQUs7WUFDOUI7O0lBRUo7SUFFQSxNQUFNTSxrQkFBa0I7UUFDdEJiLGdCQUFnQix3Q0FDWEM7WUFDSGEsa0JBQWtCLHdDQUNiYixRQUFRYSxnQkFBZ0I7Z0JBQzNCRixVQUFVOztZQUVaRCxnQkFBZ0Isd0NBQ1hWLFFBQVFVLGNBQWM7Z0JBQ3pCQyxVQUFVOzs7SUFHaEI7SUFFQSxNQUFNLEVBQUVSLFFBQVEsRUFBRVUsZ0JBQWdCLEVBQUUsR0FBR2I7SUFDdkMsTUFBTVUsaUJBQWtCVixRQUFRVSxjQUFjLElBQUksQ0FBQztJQUVuRCxxQkFDRSwyREFBQ0k7UUFBSUMsV0FBVTtxQkFDYiwyREFBQ3JCLG9EQUFXQTtRQUFDc0IsT0FBTTtRQUFNQyxZQUFZO3FCQUNuQywyREFBQ3RCLDhDQUFLQTtRQUNKdUIsVUFBVWpCO1FBQ1ZLLE9BQU9ILFNBQVNDLEdBQUcsSUFBSTtRQUN2QmUsYUFBWTtRQUNaQyxPQUFPO3VCQUdYLDJEQUFDMUIsb0RBQVdBO1FBQUNzQixPQUFNO1FBQU9DLFlBQVk7cUJBQ3BDLDJEQUFDdEIsOENBQUtBO1FBQ0p1QixVQUFVWDtRQUNWRCxPQUFPSCxTQUFTSyxJQUFJLElBQUk7UUFDeEJXLGFBQVk7UUFDWkMsT0FBTzt1QkFHWCwyREFBQzFCLG9EQUFXQTtRQUFDc0IsT0FBTTtRQUFXQyxZQUFZO3FCQUN4QywyREFBQ3JCLG9EQUFXQTtRQUNWeUIsY0FBZVIsb0JBQW9CQSxpQkFBaUJGLFFBQVE7UUFDNURMLE9BQU9JLGVBQWVDLFFBQVEsSUFBSTtRQUNsQ1EsYUFBWTtRQUNaQyxPQUFPO1FBQ1BFLFNBQVNWO1FBQ1RNLFVBQVVUOztBQUtwQiIsInNvdXJjZXMiOlsid2VicGFjazovL3JuY2Itb3JhY2xlZGF0YWJhc2VybmNiLWRhdGFzb3VyY2UvLi9jb21wb25lbnRzL0NvbmZpZ0VkaXRvci50c3g/YmVkYyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgQ2hhbmdlRXZlbnQgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBJbmxpbmVGaWVsZCwgSW5wdXQsIFNlY3JldElucHV0IH0gZnJvbSAnQGdyYWZhbmEvdWknO1xuaW1wb3J0IHsgRGF0YVNvdXJjZVBsdWdpbk9wdGlvbnNFZGl0b3JQcm9wcyB9IGZyb20gJ0BncmFmYW5hL2RhdGEnO1xuaW1wb3J0IHsgTXlEYXRhU291cmNlT3B0aW9ucywgTXlTZWN1cmVKc29uRGF0YSB9IGZyb20gJy4uL3R5cGVzJztcblxuaW50ZXJmYWNlIFByb3BzIGV4dGVuZHMgRGF0YVNvdXJjZVBsdWdpbk9wdGlvbnNFZGl0b3JQcm9wczxNeURhdGFTb3VyY2VPcHRpb25zPiB7IH1cblxuZXhwb3J0IGZ1bmN0aW9uIENvbmZpZ0VkaXRvcihwcm9wczogUHJvcHMpIHtcbiAgY29uc3QgeyBvbk9wdGlvbnNDaGFuZ2UsIG9wdGlvbnMgfSA9IHByb3BzO1xuXG4gIGNvbnN0IG9uVG5zQ2hhbmdlID0gKGV2ZW50OiBDaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50PikgPT4ge1xuICAgIGNvbnN0IGpzb25EYXRhID0ge1xuICAgICAgLi4ub3B0aW9ucy5qc29uRGF0YSxcbiAgICAgIHRuczogZXZlbnQudGFyZ2V0LnZhbHVlLFxuICAgIH07XG4gICAgb25PcHRpb25zQ2hhbmdlKHsgLi4ub3B0aW9ucywganNvbkRhdGEgfSk7XG4gIH07XG4gIFxuICBjb25zdCBvblVzZXJDaGFuZ2UgPSAoZXZlbnQ6IENoYW5nZUV2ZW50PEhUTUxJbnB1dEVsZW1lbnQ+KSA9PiB7XG4gICAgY29uc3QganNvbkRhdGEgPSB7XG4gICAgICAuLi5vcHRpb25zLmpzb25EYXRhLFxuICAgICAgdXNlcjogZXZlbnQudGFyZ2V0LnZhbHVlLFxuICAgIH07XG4gICAgb25PcHRpb25zQ2hhbmdlKHsgLi4ub3B0aW9ucywganNvbkRhdGEgfSk7XG4gIH07XG5cbiAgLy8gU2VjdXJlIGZpZWxkIChvbmx5IHNlbnQgdG8gdGhlIGJhY2tlbmQpXG4gIGNvbnN0IG9uUGFzc3dvcmRDaGFuZ2UgPSAoZXZlbnQ6IENoYW5nZUV2ZW50PEhUTUxJbnB1dEVsZW1lbnQ+KSA9PiB7XG4gICAgb25PcHRpb25zQ2hhbmdlKHtcbiAgICAgIC4uLm9wdGlvbnMsXG4gICAgICBzZWN1cmVKc29uRGF0YToge1xuICAgICAgICBwYXNzd29yZDogZXZlbnQudGFyZ2V0LnZhbHVlLFxuICAgICAgfSxcbiAgICB9KTtcbiAgfTtcblxuICBjb25zdCBvblJlc2V0UGFzc3dvcmQgPSAoKSA9PiB7XG4gICAgb25PcHRpb25zQ2hhbmdlKHtcbiAgICAgIC4uLm9wdGlvbnMsXG4gICAgICBzZWN1cmVKc29uRmllbGRzOiB7XG4gICAgICAgIC4uLm9wdGlvbnMuc2VjdXJlSnNvbkZpZWxkcyxcbiAgICAgICAgcGFzc3dvcmQ6IGZhbHNlLFxuICAgICAgfSxcbiAgICAgIHNlY3VyZUpzb25EYXRhOiB7XG4gICAgICAgIC4uLm9wdGlvbnMuc2VjdXJlSnNvbkRhdGEsXG4gICAgICAgIHBhc3N3b3JkOiAnJyxcbiAgICAgIH0sXG4gICAgfSk7XG4gIH07XG5cbiAgY29uc3QgeyBqc29uRGF0YSwgc2VjdXJlSnNvbkZpZWxkcyB9ID0gb3B0aW9ucztcbiAgY29uc3Qgc2VjdXJlSnNvbkRhdGEgPSAob3B0aW9ucy5zZWN1cmVKc29uRGF0YSB8fCB7fSkgYXMgTXlTZWN1cmVKc29uRGF0YTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2YtZm9ybS1ncm91cFwiPlxuICAgICAgPElubGluZUZpZWxkIGxhYmVsPVwiVE5TXCIgbGFiZWxXaWR0aD17Nn0+XG4gICAgICAgIDxJbnB1dFxuICAgICAgICAgIG9uQ2hhbmdlPXtvblRuc0NoYW5nZX1cbiAgICAgICAgICB2YWx1ZT17anNvbkRhdGEudG5zIHx8ICcnfVxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwic3RyaW5nIFROU1wiXG4gICAgICAgICAgd2lkdGg9ezEyMH1cbiAgICAgICAgLz5cbiAgICAgIDwvSW5saW5lRmllbGQ+XG4gICAgICA8SW5saW5lRmllbGQgbGFiZWw9XCJVc2VyXCIgbGFiZWxXaWR0aD17MTJ9PlxuICAgICAgICA8SW5wdXRcbiAgICAgICAgICBvbkNoYW5nZT17b25Vc2VyQ2hhbmdlfVxuICAgICAgICAgIHZhbHVlPXtqc29uRGF0YS51c2VyIHx8ICcnfVxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwidXNlcm5hbWVcIlxuICAgICAgICAgIHdpZHRoPXs0MH1cbiAgICAgICAgLz5cbiAgICAgIDwvSW5saW5lRmllbGQ+XG4gICAgICA8SW5saW5lRmllbGQgbGFiZWw9XCJQYXNzd29yZFwiIGxhYmVsV2lkdGg9ezEyfT5cbiAgICAgICAgPFNlY3JldElucHV0XG4gICAgICAgICAgaXNDb25maWd1cmVkPXsoc2VjdXJlSnNvbkZpZWxkcyAmJiBzZWN1cmVKc29uRmllbGRzLnBhc3N3b3JkKSBhcyBib29sZWFufVxuICAgICAgICAgIHZhbHVlPXtzZWN1cmVKc29uRGF0YS5wYXNzd29yZCB8fCAnJ31cbiAgICAgICAgICBwbGFjZWhvbGRlcj1cInNlY3VyZSBqc29uIGZpZWxkIChiYWNrZW5kIG9ubHkpXCJcbiAgICAgICAgICB3aWR0aD17NDB9XG4gICAgICAgICAgb25SZXNldD17b25SZXNldFBhc3N3b3JkfVxuICAgICAgICAgIG9uQ2hhbmdlPXtvblBhc3N3b3JkQ2hhbmdlfVxuICAgICAgICAvPlxuICAgICAgPC9JbmxpbmVGaWVsZD5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJuYW1lcyI6WyJSZWFjdCIsIklubGluZUZpZWxkIiwiSW5wdXQiLCJTZWNyZXRJbnB1dCIsIkNvbmZpZ0VkaXRvciIsInByb3BzIiwib25PcHRpb25zQ2hhbmdlIiwib3B0aW9ucyIsIm9uVG5zQ2hhbmdlIiwiZXZlbnQiLCJqc29uRGF0YSIsInRucyIsInRhcmdldCIsInZhbHVlIiwib25Vc2VyQ2hhbmdlIiwidXNlciIsIm9uUGFzc3dvcmRDaGFuZ2UiLCJzZWN1cmVKc29uRGF0YSIsInBhc3N3b3JkIiwib25SZXNldFBhc3N3b3JkIiwic2VjdXJlSnNvbkZpZWxkcyIsImRpdiIsImNsYXNzTmFtZSIsImxhYmVsIiwibGFiZWxXaWR0aCIsIm9uQ2hhbmdlIiwicGxhY2Vob2xkZXIiLCJ3aWR0aCIsImlzQ29uZmlndXJlZCIsIm9uUmVzZXQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./components/ConfigEditor.tsx\n");

/***/ }),

/***/ "./components/QueryEditor.tsx":
/*!************************************!*\
  !*** ./components/QueryEditor.tsx ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   QueryEditor: () => (/* binding */ QueryEditor)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _grafana_ui__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @grafana/ui */ \"@grafana/ui\");\n/* harmony import */ var _grafana_ui__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_grafana_ui__WEBPACK_IMPORTED_MODULE_1__);\nfunction _define_property(obj, key, value) {\n    if (key in obj) {\n        Object.defineProperty(obj, key, {\n            value: value,\n            enumerable: true,\n            configurable: true,\n            writable: true\n        });\n    } else {\n        obj[key] = value;\n    }\n    return obj;\n}\nfunction _object_spread(target) {\n    for(var i = 1; i < arguments.length; i++){\n        var source = arguments[i] != null ? arguments[i] : {};\n        var ownKeys = Object.keys(source);\n        if (typeof Object.getOwnPropertySymbols === \"function\") {\n            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {\n                return Object.getOwnPropertyDescriptor(source, sym).enumerable;\n            }));\n        }\n        ownKeys.forEach(function(key) {\n            _define_property(target, key, source[key]);\n        });\n    }\n    return target;\n}\nfunction ownKeys(object, enumerableOnly) {\n    var keys = Object.keys(object);\n    if (Object.getOwnPropertySymbols) {\n        var symbols = Object.getOwnPropertySymbols(object);\n        if (enumerableOnly) {\n            symbols = symbols.filter(function(sym) {\n                return Object.getOwnPropertyDescriptor(object, sym).enumerable;\n            });\n        }\n        keys.push.apply(keys, symbols);\n    }\n    return keys;\n}\nfunction _object_spread_props(target, source) {\n    source = source != null ? source : {};\n    if (Object.getOwnPropertyDescriptors) {\n        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));\n    } else {\n        ownKeys(Object(source)).forEach(function(key) {\n            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));\n        });\n    }\n    return target;\n}\n\n\nfunction QueryEditor({ query, onChange, onRunQuery }) {\n    const onQueryTextChange = (event)=>{\n        onChange(_object_spread_props(_object_spread({}, query), {\n            queryText: event.target.value\n        }));\n    };\n    const { queryText } = query;\n    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(\"div\", {\n        className: \"gf-form\"\n    }, /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_grafana_ui__WEBPACK_IMPORTED_MODULE_1__.TextArea, {\n        onChange: onQueryTextChange,\n        label: \"Query\",\n        value: queryText || '',\n        placeholder: \"Текст запроса\"\n    }), /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createElement(\"button\", {\n        onClick: onRunQuery\n    }, \"Выполнить запрос\"));\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL1F1ZXJ5RWRpdG9yLnRzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBMkM7QUFDSjtBQU9oQyxTQUFTRSxZQUFZLEVBQUVDLEtBQUssRUFBRUMsUUFBUSxFQUFFQyxVQUFVLEVBQVM7SUFDaEUsTUFBTUMsb0JBQW9CLENBQUNDO1FBQ3pCSCxTQUFTLHdDQUFLRDtZQUFPSyxXQUFXRCxNQUFNRSxNQUFNLENBQUNDLEtBQUs7O0lBQ3BEO0lBR0EsTUFBTSxFQUFFRixTQUFTLEVBQUUsR0FBR0w7SUFFdEIscUJBQ0UsMkRBQUNRO1FBQUlDLFdBQVU7cUJBQ2IsMkRBQUNYLGlEQUFRQTtRQUFDRyxVQUFVRTtRQUFtQk8sT0FBTTtRQUFRSCxPQUFPRixhQUFhO1FBQUlNLGFBQVk7c0JBQ3pGLDJEQUFDQztRQUFPQyxTQUFTWDtPQUFZO0FBR25DIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcm5jYi1vcmFjbGVkYXRhYmFzZXJuY2ItZGF0YXNvdXJjZS8uL2NvbXBvbmVudHMvUXVlcnlFZGl0b3IudHN4PzBhMDMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IENoYW5nZUV2ZW50IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgVGV4dEFyZWEgfSBmcm9tICdAZ3JhZmFuYS91aSc7XG5pbXBvcnQgeyBRdWVyeUVkaXRvclByb3BzIH0gZnJvbSAnQGdyYWZhbmEvZGF0YSc7XG5pbXBvcnQgeyBEYXRhU291cmNlIH0gZnJvbSAnLi4vZGF0YXNvdXJjZSc7XG5pbXBvcnQgeyBNeURhdGFTb3VyY2VPcHRpb25zLCBNeVF1ZXJ5IH0gZnJvbSAnLi4vdHlwZXMnO1xuXG50eXBlIFByb3BzID0gUXVlcnlFZGl0b3JQcm9wczxEYXRhU291cmNlLCBNeVF1ZXJ5LCBNeURhdGFTb3VyY2VPcHRpb25zPjtcblxuZXhwb3J0IGZ1bmN0aW9uIFF1ZXJ5RWRpdG9yKHsgcXVlcnksIG9uQ2hhbmdlLCBvblJ1blF1ZXJ5IH06IFByb3BzKSB7XG4gIGNvbnN0IG9uUXVlcnlUZXh0Q2hhbmdlID0gKGV2ZW50OiBDaGFuZ2VFdmVudDxIVE1MVGV4dEFyZWFFbGVtZW50PikgPT4ge1xuICAgIG9uQ2hhbmdlKHsgLi4ucXVlcnksIHF1ZXJ5VGV4dDogZXZlbnQudGFyZ2V0LnZhbHVlIH0pO1xuICB9O1xuXG4gIFxuICBjb25zdCB7IHF1ZXJ5VGV4dCB9ID0gcXVlcnk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImdmLWZvcm1cIj5cbiAgICAgIDxUZXh0QXJlYSBvbkNoYW5nZT17b25RdWVyeVRleHRDaGFuZ2V9IGxhYmVsPVwiUXVlcnlcIiB2YWx1ZT17cXVlcnlUZXh0IHx8ICcnfSBwbGFjZWhvbGRlcj1cItCi0LXQutGB0YIg0LfQsNC/0YDQvtGB0LBcIiAvPlxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvblJ1blF1ZXJ5fT7QktGL0L/QvtC70L3QuNGC0Ywg0LfQsNC/0YDQvtGBPC9idXR0b24+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwibmFtZXMiOlsiUmVhY3QiLCJUZXh0QXJlYSIsIlF1ZXJ5RWRpdG9yIiwicXVlcnkiLCJvbkNoYW5nZSIsIm9uUnVuUXVlcnkiLCJvblF1ZXJ5VGV4dENoYW5nZSIsImV2ZW50IiwicXVlcnlUZXh0IiwidGFyZ2V0IiwidmFsdWUiLCJkaXYiLCJjbGFzc05hbWUiLCJsYWJlbCIsInBsYWNlaG9sZGVyIiwiYnV0dG9uIiwib25DbGljayJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./components/QueryEditor.tsx\n");

/***/ }),

/***/ "./datasource.ts":
/*!***********************!*\
  !*** ./datasource.ts ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   DataSource: () => (/* binding */ DataSource)\n/* harmony export */ });\n/* harmony import */ var _grafana_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @grafana/runtime */ \"@grafana/runtime\");\n/* harmony import */ var _grafana_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_grafana_runtime__WEBPACK_IMPORTED_MODULE_0__);\nfunction _define_property(obj, key, value) {\n    if (key in obj) {\n        Object.defineProperty(obj, key, {\n            value: value,\n            enumerable: true,\n            configurable: true,\n            writable: true\n        });\n    } else {\n        obj[key] = value;\n    }\n    return obj;\n}\nfunction _object_spread(target) {\n    for(var i = 1; i < arguments.length; i++){\n        var source = arguments[i] != null ? arguments[i] : {};\n        var ownKeys = Object.keys(source);\n        if (typeof Object.getOwnPropertySymbols === \"function\") {\n            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {\n                return Object.getOwnPropertyDescriptor(source, sym).enumerable;\n            }));\n        }\n        ownKeys.forEach(function(key) {\n            _define_property(target, key, source[key]);\n        });\n    }\n    return target;\n}\nfunction ownKeys(object, enumerableOnly) {\n    var keys = Object.keys(object);\n    if (Object.getOwnPropertySymbols) {\n        var symbols = Object.getOwnPropertySymbols(object);\n        if (enumerableOnly) {\n            symbols = symbols.filter(function(sym) {\n                return Object.getOwnPropertyDescriptor(object, sym).enumerable;\n            });\n        }\n        keys.push.apply(keys, symbols);\n    }\n    return keys;\n}\nfunction _object_spread_props(target, source) {\n    source = source != null ? source : {};\n    if (Object.getOwnPropertyDescriptors) {\n        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));\n    } else {\n        ownKeys(Object(source)).forEach(function(key) {\n            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));\n        });\n    }\n    return target;\n}\n\nclass DataSource extends _grafana_runtime__WEBPACK_IMPORTED_MODULE_0__.DataSourceWithBackend {\n    applyTemplateVariables(query) {\n        const templateSrv = (0,_grafana_runtime__WEBPACK_IMPORTED_MODULE_0__.getTemplateSrv)();\n        return _object_spread_props(_object_spread({}, query), {\n            queryText: query.queryText ? templateSrv.replace(query.queryText) : ''\n        });\n    }\n    constructor(instanceSettings){\n        super(instanceSettings);\n        _define_property(this, \"config\", void 0);\n        this.config = instanceSettings.jsonData;\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9kYXRhc291cmNlLnRzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDeUU7QUFLbEUsTUFBTUUsbUJBQW1CRixtRUFBcUJBO0lBVW5ERyx1QkFBdUJDLEtBQWMsRUFBRTtRQUNyQyxNQUFNQyxjQUFjSixnRUFBY0E7UUFDbEMsT0FBTyx3Q0FDRkc7WUFDSEUsV0FBV0YsTUFBTUUsU0FBUyxHQUFHRCxZQUFZRSxPQUFPLENBQUNILE1BQU1FLFNBQVMsSUFBSTs7SUFFeEU7SUFaQUUsWUFBWUMsZ0JBQWlFLENBQUU7UUFDN0UsS0FBSyxDQUFDQTtRQUhSQyx1QkFBQUEsVUFBQUEsS0FBQUE7UUFJRSxJQUFJLENBQUNBLE1BQU0sR0FBR0QsaUJBQWlCRSxRQUFRO0lBQ3pDO0FBV0YiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9ybmNiLW9yYWNsZWRhdGFiYXNlcm5jYi1kYXRhc291cmNlLy4vZGF0YXNvdXJjZS50cz9lYWIwIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERhdGFTb3VyY2VJbnN0YW5jZVNldHRpbmdzIH0gZnJvbSAnQGdyYWZhbmEvZGF0YSc7XG5pbXBvcnQgeyBEYXRhU291cmNlV2l0aEJhY2tlbmQsIGdldFRlbXBsYXRlU3J2IH0gZnJvbSAnQGdyYWZhbmEvcnVudGltZSc7XG5cbmltcG9ydCB7IE15UXVlcnksIE15RGF0YVNvdXJjZU9wdGlvbnMgfSBmcm9tICcuL3R5cGVzJztcblxuXG5leHBvcnQgY2xhc3MgRGF0YVNvdXJjZSBleHRlbmRzIERhdGFTb3VyY2VXaXRoQmFja2VuZDxNeVF1ZXJ5LCBNeURhdGFTb3VyY2VPcHRpb25zPiB7XG5cbiAgY29uZmlnOiBNeURhdGFTb3VyY2VPcHRpb25zXG5cbiAgY29uc3RydWN0b3IoaW5zdGFuY2VTZXR0aW5nczogRGF0YVNvdXJjZUluc3RhbmNlU2V0dGluZ3M8TXlEYXRhU291cmNlT3B0aW9ucz4pIHtcbiAgICBzdXBlcihpbnN0YW5jZVNldHRpbmdzKTtcbiAgICB0aGlzLmNvbmZpZyA9IGluc3RhbmNlU2V0dGluZ3MuanNvbkRhdGE7XG4gIH1cblxuXG4gIGFwcGx5VGVtcGxhdGVWYXJpYWJsZXMocXVlcnk6IE15UXVlcnkpIHtcbiAgICBjb25zdCB0ZW1wbGF0ZVNydiA9IGdldFRlbXBsYXRlU3J2KCk7XG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLnF1ZXJ5LFxuICAgICAgcXVlcnlUZXh0OiBxdWVyeS5xdWVyeVRleHQgPyB0ZW1wbGF0ZVNydi5yZXBsYWNlKHF1ZXJ5LnF1ZXJ5VGV4dCkgOiAnJyxcbiAgICB9O1xuICB9XG5cbn1cbiJdLCJuYW1lcyI6WyJEYXRhU291cmNlV2l0aEJhY2tlbmQiLCJnZXRUZW1wbGF0ZVNydiIsIkRhdGFTb3VyY2UiLCJhcHBseVRlbXBsYXRlVmFyaWFibGVzIiwicXVlcnkiLCJ0ZW1wbGF0ZVNydiIsInF1ZXJ5VGV4dCIsInJlcGxhY2UiLCJjb25zdHJ1Y3RvciIsImluc3RhbmNlU2V0dGluZ3MiLCJjb25maWciLCJqc29uRGF0YSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./datasource.ts\n");

/***/ }),

/***/ "./module.ts":
/*!*******************!*\
  !*** ./module.ts ***!
  \*******************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   plugin: () => (/* binding */ plugin)\n/* harmony export */ });\n/* harmony import */ var _grafana_data__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @grafana/data */ \"@grafana/data\");\n/* harmony import */ var _grafana_data__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_grafana_data__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _datasource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./datasource */ \"./datasource.ts\");\n/* harmony import */ var _components_ConfigEditor__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/ConfigEditor */ \"./components/ConfigEditor.tsx\");\n/* harmony import */ var _components_QueryEditor__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/QueryEditor */ \"./components/QueryEditor.tsx\");\n\n\n\n\nconst plugin = new _grafana_data__WEBPACK_IMPORTED_MODULE_0__.DataSourcePlugin(_datasource__WEBPACK_IMPORTED_MODULE_1__.DataSource).setConfigEditor(_components_ConfigEditor__WEBPACK_IMPORTED_MODULE_2__.ConfigEditor).setQueryEditor(_components_QueryEditor__WEBPACK_IMPORTED_MODULE_3__.QueryEditor);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9tb2R1bGUudHMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQWlEO0FBQ1A7QUFDZTtBQUNGO0FBR2hELE1BQU1JLFNBQVMsSUFBSUosMkRBQWdCQSxDQUEyQ0MsbURBQVVBLEVBQzVGSSxlQUFlLENBQUNILGtFQUFZQSxFQUM1QkksY0FBYyxDQUFDSCxnRUFBV0EsRUFBRSIsInNvdXJjZXMiOlsid2VicGFjazovL3JuY2Itb3JhY2xlZGF0YWJhc2VybmNiLWRhdGFzb3VyY2UvLi9tb2R1bGUudHM/YzIxNCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEYXRhU291cmNlUGx1Z2luIH0gZnJvbSAnQGdyYWZhbmEvZGF0YSc7XG5pbXBvcnQgeyBEYXRhU291cmNlIH0gZnJvbSAnLi9kYXRhc291cmNlJztcbmltcG9ydCB7IENvbmZpZ0VkaXRvciB9IGZyb20gJy4vY29tcG9uZW50cy9Db25maWdFZGl0b3InO1xuaW1wb3J0IHsgUXVlcnlFZGl0b3IgfSBmcm9tICcuL2NvbXBvbmVudHMvUXVlcnlFZGl0b3InO1xuaW1wb3J0IHsgTXlRdWVyeSwgTXlEYXRhU291cmNlT3B0aW9ucyB9IGZyb20gJy4vdHlwZXMnO1xuXG5leHBvcnQgY29uc3QgcGx1Z2luID0gbmV3IERhdGFTb3VyY2VQbHVnaW48RGF0YVNvdXJjZSwgTXlRdWVyeSwgTXlEYXRhU291cmNlT3B0aW9ucz4oRGF0YVNvdXJjZSlcbiAgLnNldENvbmZpZ0VkaXRvcihDb25maWdFZGl0b3IpXG4gIC5zZXRRdWVyeUVkaXRvcihRdWVyeUVkaXRvcik7XG4iXSwibmFtZXMiOlsiRGF0YVNvdXJjZVBsdWdpbiIsIkRhdGFTb3VyY2UiLCJDb25maWdFZGl0b3IiLCJRdWVyeUVkaXRvciIsInBsdWdpbiIsInNldENvbmZpZ0VkaXRvciIsInNldFF1ZXJ5RWRpdG9yIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./module.ts\n");

/***/ }),

/***/ "@grafana/data":
/*!********************************!*\
  !*** external "@grafana/data" ***!
  \********************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__grafana_data__;

/***/ }),

/***/ "@grafana/runtime":
/*!***********************************!*\
  !*** external "@grafana/runtime" ***!
  \***********************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__grafana_runtime__;

/***/ }),

/***/ "@grafana/ui":
/*!******************************!*\
  !*** external "@grafana/ui" ***!
  \******************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__grafana_ui__;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE_react__;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval-source-map devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./module.ts");
/******/ 	
/******/ 	return __webpack_exports__;
/******/ })()
;
});;